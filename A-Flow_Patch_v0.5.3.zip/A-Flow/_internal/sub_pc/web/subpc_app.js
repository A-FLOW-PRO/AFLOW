/* 서브 PC 웹 화면 — 메인 A-FLOW 의 REST API(/api/v1/…)를 부른다. 처리는 전부 메인이 한다.
 *
 * ⚠ 화면에 넣는 글자는 **전부 textContent** 다(주문·문의 글에 무엇이 들어 있을지 모른다).
 * ⚠ 링크는 **https:// 만** 연다.
 * ⚠ 평문 HTTP(같은 공유기)라 브라우저의 암호 기능·알림 팝업(secure context 전용)을 못 쓴다 —
 *   비밀번호는 메인이 바꿔 비교하고(main_rest_api._login), 알림은 소리·탭 제목·배너로 한다.
 * ⚠ 쓰기는 Idempotency-Key 를 단다 — 끊겨 다시 보내도 메인이 두 번 실행하지 않는다.
 * ⚠ 마켓 조회는 [메인에서 다시 조회] 를 눌렀을 때만 — 탭을 옮기거나 20초 확인으로는 안 나간다.
 */
(function () {
  "use strict";

  // ── 저장(이 브라우저만) ───────────────────────────────────────
  function sget(k) { try { return localStorage.getItem(k) || sessionStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function sset(k, v, keep) {
    try {
      localStorage.removeItem(k); sessionStorage.removeItem(k);
      if (v) (keep ? localStorage : sessionStorage).setItem(k, v);
    } catch (e) { /* 저장이 막힌 브라우저 — 이번 창에서만 쓴다 */ }
  }
  function lget(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function lset(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* 무시 */ } }

  function randHex(n) {
    var a = new Uint8Array(n); crypto.getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  var DEVICE = lget("aflow_subpc_device") || randHex(12);
  lset("aflow_subpc_device", DEVICE);

  var S = { token: sget("aflow_subpc_token"), me: null, meta: {}, tab: "new", rows: [],
            sel: {}, focus: -1, edits: {}, alertSeq: null, busy: false, counts: {}, gen: 0 };
  // ⚠ S.gen — 탭을 바꿀 때마다 올린다. 늦게 온 **이전 탭의 응답**은 버린다(안 버리면 정산 결과가
  //   문의 탭 화면을 덮고, '처리 중' 이 남아 새 탭 목록을 못 받는다 — testcode/test_subpc_web.py).
  function stale(g) { return g !== S.gen; }

  // ── 화면 도우미 ───────────────────────────────────────────────
  function $(id) { return document.getElementById(id); }
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === "text") e.textContent = attrs[k];
      else if (k === "cls") e.className = attrs[k];
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
    return e;
  }
  function clear(e) { while (e.firstChild) e.removeChild(e.firstChild); }
  function won(v) { var n = parseInt(v, 10); return isNaN(n) ? (v || "") : n.toLocaleString("ko-KR"); }
  // ⚠ 링크는 http(s) 주소만 연다(`javascript:` 같은 것은 버린다). 메모에 적힌 구매 링크는 http 인 것도 있다.
  function safeUrl(u) { return /^https?:\/\//i.test(String(u || "")) ? String(u) : ""; }
  function note(t) { $("note").textContent = t || ""; }

  // ── REST ──────────────────────────────────────────────────────
  function api(method, path, opt) {
    opt = opt || {};
    var url = path;
    if (opt.query) {
      var q = Object.keys(opt.query).filter(function (k) { return opt.query[k] !== "" && opt.query[k] != null; })
        .map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(opt.query[k]); }).join("&");
      if (q) url += "?" + q;
    }
    var h = { "Content-Type": "application/json" };
    if (S.token) h["Authorization"] = "Bearer " + S.token;
    if (opt.idem) h["Idempotency-Key"] = opt.idem;
    var t0 = Date.now();
    // ⚠ 요청마다 시간 제한 — 메인이 답하지 않을 때 '받는 중…' 에 영원히 멈춰 있지 않게.
    //   마켓에 묻는 것(조회·답변·취소·링크 읽기)은 길게, 나머지는 짧게.
    var long = /\/refresh$|\/answer$|\/cancel$|\/oc-|fill-from-link|\/history$|\/auth\/login\//.test(path);
    var limit = long ? 210 : 40;
    var ctl = window.AbortController ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, limit * 1000) : null;
    return fetch(url, { method: method, headers: h, signal: ctl ? ctl.signal : undefined,
                        body: opt.body ? JSON.stringify(opt.body) : undefined })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (timer) clearTimeout(timer);
          if (path === "/api/v1/status") S.latency = Date.now() - t0;
          if (r.status === 401 && S.token && path.indexOf("/auth/login") < 0) { loggedOut(j.message); }
          if (r.status >= 500) setState("⚠ 메인 PC 오류 — " + (j.message || r.status) + " (" + clock() + ")");
          return { status: r.status, body: j || {} };
        });
      })
      .catch(function (e) {
        if (timer) clearTimeout(timer);
        var why = e && e.name === "AbortError"
          ? "메인 PC 가 " + limit + "초 안에 답하지 않았습니다 — 메인 PC 가 바쁘거나 멈춰 있습니다."
          : "메인 PC 에 닿지 않습니다 — 메인 PC 의 A-FLOW 가 켜져 있는지, 같은 공유기인지 확인해 주세요."
            + (e && e.message ? " (" + e.message + ")" : "");
        setState("🔴 " + why + " (" + clock() + ")");
        return { status: 0, body: { ok: false, message: why } };
      });
  }
  function clock() { var d = new Date(); return ("0" + d.getHours()).slice(-2) + ":" +
                     ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2); }
  // 명령 하나 — ROUTES 와 같은 경로(sub_pc/common_proto.py). → {ok, message, data}
  function cmd(method, path, opt) {
    return api(method, path, opt).then(function (r) {
      return { ok: r.status === 200, message: r.body.message || (r.status === 200 ? "" : "처리하지 못했습니다(" + r.status + ")."),
               data: r.body.data, status: r.status };
    });
  }
  function enc(v) { return encodeURIComponent(String(v || "")); }

  // ── 로그인 ────────────────────────────────────────────────────
  function showLogin(msg) {
    $("app").classList.add("hidden"); $("login").classList.remove("hidden");
    $("lg-msg").textContent = msg || "";
    $("lg-id").value = lget("aflow_subpc_id");
    $("lg-dev").value = lget("aflow_subpc_devname");
    (lget("aflow_subpc_id") ? $("lg-pw") : $("lg-id")).focus();
  }
  function loggedOut(why) {
    S.token = ""; sset("aflow_subpc_token", "");
    stopWatch();
    showLogin("⚠ " + (why || "로그인이 끝났습니다. 다시 로그인해 주세요."));
  }
  var waiting = false;
  function doLogin() {
    if (waiting) return;
    var id = $("lg-id").value.trim(), pw = $("lg-pw").value;
    if (!id || !pw) { $("lg-msg").textContent = "아이디와 비밀번호를 넣어 주세요."; return; }
    lset("aflow_subpc_id", id); lset("aflow_subpc_devname", $("lg-dev").value.trim());
    unlockSound();
    waiting = true; $("lg-go").disabled = true;
    $("lg-msg").textContent = "메인 PC 에 로그인하는 중…";
    api("POST", "/api/v1/auth/login", { body: { login_id: id, password: pw, device_id: DEVICE,
        device_name: $("lg-dev").value.trim() || "서브 PC(브라우저)" } }).then(loginStep);
  }
  function loginStep(r) {
    var b = r.body || {};
    if (r.status === 200 && b.token) {
      waiting = false; $("lg-go").disabled = false; $("lg-pw").value = "";
      S.token = b.token; sset("aflow_subpc_token", b.token, $("lg-keep").checked);
      return start();
    }
    if (r.status === 202) {
      $("lg-msg").textContent = "⏳ " + (b.message || "메인 PC 사용자의 승인을 기다리는 중입니다.") +
        "\n(텔레그램 또는 메인 PC 화면에서 [승인] 을 누르면 들어갑니다)";
      return api("GET", "/api/v1/auth/login/" + enc(b.request_id), { query: { wait: 20 } }).then(loginStep);
    }
    waiting = false; $("lg-go").disabled = false;
    $("lg-msg").textContent = "❌ " + (b.message || "로그인하지 못했습니다(" + r.status + ").");
  }

  // ── 시작 · 탭 ──────────────────────────────────────────────────
  var TABS = [
    { key: "new", label: "🥳 신규주문", list: ["GET", "/api/v1/orders", { tab: "new" }], cnt: "new" },
    { key: "ship", label: "🚚 발송관리", list: ["GET", "/api/v1/orders", { tab: "ship" }], cnt: "ship" },
    { key: "claim", label: "↩ 취소·반품·교환", list: ["GET", "/api/v1/orders", { tab: "claim" }], cnt: "claim" },
    { key: "qna", label: "😡 긴급·문의", list: ["GET", "/api/v1/inquiries", null], cnt: "qna" },
    { key: "search", label: "🔎 주문통합검색", perm: "perm_search" },
    { key: "settle", label: "💰 정산", perm: "perm_settle" }
  ];
  function start() {
    $("login").classList.add("hidden"); $("app").classList.remove("hidden");
    return cmd("GET", "/api/v1/me").then(function (r) {
      if (!r.ok) return;
      S.me = r.data;
      $("hd-who").textContent = "👤 " + S.me.name + (S.me.main_name ? " · 메인 " + S.me.main_name : "");
      cmd("GET", "/api/v1/meta").then(function (m) { if (m.ok) S.meta = m.data || {}; });
      drawTabs(); go(S.tab === "search" || S.tab === "settle" ? "new" : S.tab);
      startWatch();
    });
  }
  function allowed(t) { return !t.perm || (S.me && S.me.perms && S.me.perms[t.perm]); }
  function drawTabs() {
    var nav = $("tabs"); clear(nav);
    TABS.filter(allowed).forEach(function (t) {
      var n = t.cnt && S.counts[t.cnt] != null ? " (" + S.counts[t.cnt] + ")" : "";
      var cls = (t.key === S.tab ? "on" : "") + (S.alertTabs && S.alertTabs[t.key] ? " alert" : "");
      nav.appendChild(el("button", { cls: cls, text: t.label + n,
        onclick: function () { go(t.key); } }));
    });
  }
  function tabOf(k) { return TABS.filter(function (t) { return t.key === k; })[0]; }
  function go(k) {
    S.gen++; S.busy = false;
    S.tab = k; S.rows = []; S.sel = {}; S.focus = -1; S.edits = {};
    if (S.alertTabs) delete S.alertTabs[k];          // 그 탭을 열었으면 깜빡임을 멈춘다
    clear($("detail"));
    drawTabs(); drawToolbar(); drawGrid(); drawDetail();
    if (k === "search" || k === "settle") { note(""); return; }
    load(false);
  }

  function load(market) {
    var t = tabOf(S.tab);
    if (!t.list || S.busy) return;
    busy(true, market ? "메인 PC 에 마켓 조회를 시키는 중…(최대 1분)" : "메인 PC 에서 목록을 받는 중…");
    var g = S.gen;
    var p = market ? cmd("POST", "/api/v1/refresh", { body: { tab: S.tab } })
                   : cmd(t.list[0], t.list[1], { query: t.list[2] });
    p.then(function (r) {
      if (stale(g)) return;
      busy(false);
      if (!r.ok || !r.data) { note("❌ " + r.message); return; }
      S.rows = r.data.rows || []; S.sel = {}; S.focus = -1; S.edits = {};
      if (r.data.counts) { S.counts = r.data.counts; drawTabs(); }
      var bits = [r.message, r.data.note].filter(Boolean);
      bits.push((r.data.total != null ? r.data.total : S.rows.length) + "건");
      note(bits.join(" · "));
      drawGrid(); drawDetail();
    }).catch(function (e) {
      // ⚠ 표를 그리다 오류가 나도 '받는 중…' 으로 굳지 않게 — 무엇이 잘못됐는지 글자로.
      if (stale(g)) return;
      busy(false);
      note("❌ 목록을 화면에 그리지 못했습니다: " + (e && e.message ? e.message : e));
    });
  }
  function busy(on, t) {
    S.busy = on;
    Array.prototype.forEach.call(document.querySelectorAll("#toolbar button, #detail button"),
      function (b) { b.disabled = on; });
    if (t) note(t);
  }

  // ── 버튼 줄 ───────────────────────────────────────────────────
  function drawToolbar() {
    var tb = $("toolbar"); clear(tb);
    function b(text, fn, cls) { tb.appendChild(el("button", { text: text, cls: cls || "", onclick: fn })); }
    if (S.tab === "search") return drawSearchBar(tb);
    if (S.tab === "settle") return drawSettleBar(tb);
    b("🔄 메인에서 다시 조회(마켓에 묻기)", function () { load(true); });
    b("📋 목록만 새로 받기", function () { load(false); });
    if (S.tab === "new") {
      b("✅ 주문확인(마켓에 보냄)", doConfirm, "primary");
      b("❌ 주문취소", doCancel, "danger");
    }
    if (S.tab === "ship") b("🚚 발송처리(마켓에 보냄)", doShip, "primary");
    if (S.tab === "claim") b("✔ 취소 승인(마켓에 보냄)", doCancelApprove, "primary");
    // 메모·과거 구매내역·배송조회는 표의 줄마다 버튼으로 있다(사용자 요청 2026-10-21 — `_act` 칸).
  }

  // ── 표 ────────────────────────────────────────────────────────
  var COLS = {
    new: [["", "_act"], ["마켓", "site"], ["계정", "acc"], ["주문번호", "order_no"], ["상품명", "goods"],
          ["수량", "qty"], ["판매가", function (r) { return won(r.amount); }], ["주문자", "buyer"],
          ["받는 분", "r_name"], ["주문일", "order_at"], ["발송기한", "due"]],
    // ⚠ 수익은 서브 화면에 보이지 않는다 — 판매가만(사용자 요청 2026-10-21).
    // 택배사·송장번호는 마켓 왼쪽 — 입력하는 칸이 먼저 보이게(사용자 요청 2026-10-21).
    // 발주를 맨 앞으로(사용자 요청 2026-10-21).
    ship: [["발주", "order_note"], ["", "_act"], ["택배사", "_dlv"], ["송장번호", "_inv"], ["마켓", "site"],
           ["계정", "acc"], ["주문번호", "order_no"], ["상품명", "goods"], ["수량", "qty"],
           ["판매가", function (r) { return won(r.amount); }], ["받는 분", "r_name"]],
    claim: [["구분", "kind"], ["상태", "status"], ["사유", "reason"], ["마켓", "site"], ["계정", "acc"],
            ["주문번호", "order_no"], ["상품명", "goods"], ["금액", function (r) { return won(r.amount); }],
            ["요청일", "at"]],
    qna: [["마켓", "site"], ["계정", "acc"], ["유형", "type"], ["상품명", "goods"],
          ["문의 내용", function (r) { return String(r.question || "").replace(/\s+/g, " ").slice(0, 80); }],
          ["작성자", "buyer"], ["작성일", "at"], ["상태", "state"]],
    search: [["결제일", "at"], ["마켓", "site"], ["판매자", "seller_id"], ["주문번호", "order_no"],
             ["상품명", "goods"], ["수량", "qty"], ["판매가", function (r) { return won(r.sale); }],
             ["상태", "status"], ["받는 분", "r_name"], ["구매처", "supplier"], ["구매가", "price"]],
    settle: [["날짜", "day"], ["건수", "count"], ["매출", function (r) { return won(r.sale); }],
             ["받을 돈", function (r) { return won(r.settle); }],
             ["물건 값", function (r) { return won(r.order_amount); }],
             ["광고비", function (r) { return won(r.ad); }],
             ["내가 번 돈", function (r) { return won(r.profit); }]]
  };
  function rowKey(r) { return String(r.memo_key || r.order_no || r.inquiry_id || ""); }
  function editOf(r) {
    var k = rowKey(r);
    if (!S.edits[k]) S.edits[k] = { code: String(r.delivery_code || ""), name: r.delivery || "", inv: r.invoice || "" };
    return S.edits[k];
  }
  function dlvCell(r) {
    var ed = editOf(r);
    var sel = el("select", { onchange: function () {
      ed.code = sel.value; ed.name = sel.options[sel.selectedIndex].text; }, onclick: stop });
    sel.appendChild(el("option", { value: "", text: "택배사 선택" }));
    (S.meta.delivery_companies || []).forEach(function (c) {
      var o = el("option", { value: String(c[0]), text: c[1] });
      if (String(c[0]) === ed.code) o.selected = true;
      sel.appendChild(o);
    });
    if (ed.code && !sel.value) {   // 목록에 없는 코드(메인 화면에서 직접 고른 것)
      var o2 = el("option", { value: ed.code, text: ed.name || ed.code }); o2.selected = true; sel.appendChild(o2);
    }
    return sel;
  }
  function invCell(r) {
    var ed = editOf(r);
    return el("input", { cls: "inv", value: ed.inv, placeholder: "송장번호", onclick: stop,
      oninput: function (e) { ed.inv = e.target.value.trim(); } });
  }
  function stop(e) { e.stopPropagation(); }
  // 줄마다 [📝] [📜] [🚚](메모·과거내역·배송조회) — 누른 줄에만 한다(고른 줄과 무관).
  // ⚠ 글자 없이 아이콘만(사용자 요청 2026-10-21) — 이름은 마우스를 올리면 뜨는 설명과 aria-label 에 둔다.
  function actCell(r) {
    var box = el("span", { cls: "acts" });
    function b(text, title, fn, off) {
      var x = el("button", { cls: "mini icon", text: text, title: title, onclick: function (e) {
        e.stopPropagation(); if (!off) fn(); } });
      x.setAttribute("aria-label", title.split(" — ")[0]);
      if (off) { x.disabled = true; }
      box.appendChild(x);
    }
    b("📝", "메모 — 이 주문의 구매처·구매가·링크(메인 PC 에 저장)", function () { doMemo(r); });
    b("📜", "과거내역 — 같은 상품의 과거 구매내역", function () { doHistory(r); }, !r.goods_no);
    var st = r.memo && safeUrl(r.memo.status_link);
    b("🚚", st ? "배송조회 — 메모에 적힌 배송조회 링크를 엽니다" : "배송조회 — 메모에 배송조회 링크가 없습니다",
      function () { openLink(st, isCoupang(st)); }, !st);
    return box;
  }
  function drawGrid() {
    var cols = COLS[S.tab] || [], thead = $("grid").tHead, tbody = $("grid").tBodies[0];
    clear(thead); clear(tbody);
    var multi = S.tab !== "search" && S.tab !== "settle" && S.tab !== "qna";
    var hr = el("tr");
    if (multi) {
      var all = el("input", { type: "checkbox", title: "모두 고르기", onclick: function (e) {
        S.rows.forEach(function (_r, i) { S.sel[i] = e.target.checked; }); drawGrid(); } });
      hr.appendChild(el("th", {}, [all]));
    }
    cols.forEach(function (c) { hr.appendChild(el("th", { text: c[0] })); });
    thead.appendChild(hr);
    S.rows.forEach(function (r, i) {
      var tr = el("tr", { cls: S.sel[i] || S.focus === i ? "sel" : "", onclick: function () {
        S.focus = i; if (multi) S.sel[i] = !S.sel[i]; drawGrid(); drawDetail(); } });
      if (multi) {
        var cb = el("input", { type: "checkbox", onclick: function (e) { e.stopPropagation();
          S.sel[i] = e.target.checked; S.focus = i; drawGrid(); drawDetail(); } });
        cb.checked = !!S.sel[i];
        tr.appendChild(el("td", {}, [cb]));
      }
      cols.forEach(function (c) {
        var f = c[1], td = el("td");
        if (f === "_act") td.appendChild(actCell(r));
        else if (f === "_dlv") td.appendChild(dlvCell(r));
        else if (f === "_inv") td.appendChild(invCell(r));
        else {
          var v = typeof f === "function" ? f(r) : r[f];
          td.textContent = v == null ? "" : String(v);
          td.title = td.textContent;
          if (f === "order_note") td.className = r.ordered ? "tag-ok" : "tag-warn";
        }
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
  }
  function picked() {
    return S.rows.filter(function (_r, i) { return S.sel[i]; });
  }
  function current() { return S.focus >= 0 ? S.rows[S.focus] : null; }

  // ── 오른쪽 상세 ───────────────────────────────────────────────
  function kv(pairs) {
    var box = el("div", { cls: "kv" });
    pairs.forEach(function (p) {
      if (p[1] == null || String(p[1]).trim() === "") return;
      box.appendChild(el("b", { text: p[0] })); box.appendChild(el("span", { text: String(p[1]) }));
    });
    return box;
  }
  function drawDetail() {
    var d = $("detail"), r = current();
    if (S.tab === "settle") return;              // 정산은 요약 카드가 자리를 쓴다(계산 때 그린다)
    clear(d);
    if (S.tab === "search" && !r) return;
    if (!r) { d.appendChild(el("p", { cls: "muted", text: "왼쪽 표에서 줄을 누르면 자세한 내용이 여기에 보입니다." })); return; }
    if (S.tab === "qna") return drawQnaDetail(d, r);
    d.appendChild(el("h3", { text: (r.site || "") + " · " + (r.order_no || "") }));
    d.appendChild(kv([["상품", r.goods], ["수량", r.qty], ["금액", r.amount != null ? won(r.amount) + "원" : (r.sale != null ? won(r.sale) + "원" : "")],
      ["옵션", r.r_option], ["추가옵션", r.r_option_add], ["주문자", r.buyer], ["받는 분", r.r_name],
      ["연락처", r.r_phone], ["우편번호", r.r_zip], ["주소", r.r_addr], ["배송메모", r.r_memo],
      ["발송기한", r.due], ["발주", r.order_note], ["상태", r.status], ["사유", r.reason],
      ["택배", ((r.delivery || "") + " " + (r.invoice || "")).trim()], ["판매자", r.seller_id], ["관리코드", r.mng_code],
      ["구매처", r.supplier || (r.memo && r.memo.supplier)], ["구매가", r.price || (r.memo && r.memo.price)],
      ["비고", r.memo && r.memo.note]]));
    if (r.why) d.appendChild(el("p", { cls: "tag-warn", text: r.why }));
    // ⚠ 메모의 구매 링크·배송조회 링크는 여기 싣지 않는다(사용자 요청) — 배송조회는 표의 버튼으로.
    drawLinks(d, r.links || []);
  }
  // 구매·연결 링크 버튼. ⚠ 메인이 준 [라벨, 색, 주소, 파트너스로 바꿀 것] 만 그린다.
  function drawLinks(d, links) {
    links = (links || []).filter(function (l) { return safeUrl(l[2]); });
    if (!links.length) return;
    d.appendChild(el("h3", { text: "🔗 구매·연결 링크" }));
    var box = el("div", { cls: "links" });
    links.forEach(function (l) {
      var need = !!l[3] || isCoupang(l[2]);
      var a = el("a", { href: "#", cls: "lnk", text: "🔗 " + l[0] + (need ? " (쿠팡 파트너스)" : ""),
        onclick: function (e) { e.preventDefault(); openLink(l[2], need); } });
      // 마켓·구매처마다 다른 색(메인이 정한 색 — `main_rows.links_for`). ⚠ #rgb·#rrggbb 만 받는다.
      if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(String(l[1] || ""))) a.style.background = l[1];
      box.appendChild(a);
    });
    d.appendChild(box);
    // ⚠ 대가성 문구는 서브 화면에 싣지 않는다(사용자 결정 2026-10-21 — 직원용 화면).
  }
  // ⚠⚠ 쿠팡은 **반드시 내 쿠팡 파트너스 링크로** 연다(사용자 요청 2026-10-21) — 누르는 순간 메인에 바꿔
  //   달라고 하고(`GET /api/v1/link`), 못 바꾸면 원래 쿠팡 주소로 **열지 않는다**.
  //   ⚠ 창은 누른 순간 먼저 연다(나중에 열면 브라우저가 팝업으로 막는다) — 주소는 받은 뒤 넣는다.
  function isCoupang(u) {
    try { var h = new URL(u).hostname.toLowerCase(); return /(^|\.)coupang\.com$/.test(h) && h !== "link.coupang.com"; }
    catch (e) { return false; }
  }
  function openLink(url, need) {
    url = safeUrl(url);
    if (!url) return;
    if (!need) { window.open(url, "_blank", "noopener"); return; }
    var w = window.open("about:blank", "_blank");
    if (w) { try { w.document.title = "쿠팡 파트너스 링크 만드는 중…"; w.document.body.textContent = "쿠팡 파트너스 링크를 만드는 중입니다…"; } catch (e) { /* 무시 */ } }
    cmd("GET", "/api/v1/link", { query: { url: url } }).then(function (x) {
      var to = x.ok && x.data ? safeUrl(x.data.url) : "";
      if (!to) {
        if (w) w.close();
        alert(x.message || "쿠팡 파트너스 링크를 만들지 못했습니다 — 잠시 뒤 다시 눌러 주세요.");
        return;
      }
      if (w) { w.opener = null; w.location.href = to; } else { window.open(to, "_blank", "noopener"); }
    });
  }
  function drawQnaDetail(d, r) {
    d.appendChild(el("h3", { text: (r.site || "") + " · " + (r.type || "문의") }));
    d.appendChild(kv([["상품", r.goods], ["작성자", r.buyer], ["작성일", r.at], ["상태", r.state],
      ["주문번호", r.order_no]]));
    d.appendChild(el("div", { cls: "q", text: r.question || "" }));
    var ta = el("textarea", { placeholder: "답변을 적고 [답변 보내기] 를 누르세요." });
    d.appendChild(ta);
    d.appendChild(el("div", { cls: "row" }, [el("button", { cls: "primary", text: "💬 답변 보내기(마켓에 보냄)",
      onclick: function () { doAnswer(r, ta); } })]));
  }

  // ── 쓰기 ──────────────────────────────────────────────────────
  function pickMsg(what) { return what + " 할 줄을 먼저 고르세요 — 표에서 줄을 누르면 고릅니다(여러 줄 가능)."; }
  function runMany(path, items, what) {
    // 여러 줄을 하나씩 차례로 보낸다(메인이 주문마다 잠근다).
    busy(true, what + " " + items.length + "건 보내는 중…");
    var good = 0, bad = [];
    var seq = Promise.resolve();
    items.forEach(function (it) {
      seq = seq.then(function () {
        return cmd("POST", it.path, { body: it.body, idem: randHex(16) }).then(function (r) {
          if (r.ok) good++; else bad.push((it.label || "") + ": " + r.message);
        });
      });
    });
    seq.then(function () {
      busy(false);
      note((bad.length ? "⚠ " : "✅ ") + what + " 성공 " + good + "건, 실패 " + bad.length + "건");
      if (bad.length) alert(what + " 실패\n\n" + bad.slice(0, 8).join("\n"));
      if (good) setTimeout(function () { load(true); }, 1200);
    });
  }
  var CONFIRM_KEYS = ["acc", "site_id", "box_id", "product_order_id", "dlv_no", "ord_prd_seq", "add_prd_yn", "add_prd_no"];
  function doConfirm() {
    var sel = picked(); if (!sel.length) return alert(pickMsg("주문확인"));
    if (!confirm(sel.length + "건을 주문확인합니다(마켓에 보냅니다).")) return;
    runMany(null, sel.map(function (r) {
      var b = {}; CONFIRM_KEYS.forEach(function (k) { if (r[k] !== undefined && r[k] !== "") b[k] = r[k]; });
      return { path: "/api/v1/orders/" + enc(r.order_no) + "/confirm", body: b, label: r.order_no };
    }), "주문확인");
  }
  function doShip() {
    var sel = picked(); if (!sel.length) return alert(pickMsg("발송처리"));
    var direct = String(S.meta.direct_code || "10098"), miss = [];
    var items = sel.map(function (r) {
      var ed = editOf(r);
      if (!ed.code || (!ed.inv && ed.code !== direct)) miss.push(r.order_no);
      return { path: "/api/v1/orders/" + enc(r.order_no) + "/ship", label: r.order_no,
               body: { memo_key: r.memo_key, delivery_code: ed.code, delivery: ed.name, invoice: ed.inv } };
    });
    if (miss.length) return alert("택배사·송장번호가 비어 있는 줄이 있습니다: " + miss.slice(0, 6).join(", ") +
      "\n표의 택배사·송장번호 칸을 채운 뒤 다시 눌러 주세요.");
    if (!confirm(items.length + "건을 발송처리합니다(마켓에 보냅니다).")) return;
    runMany(null, items, "발송처리");
  }
  function doCancelApprove() {
    var sel = picked(); if (!sel.length) return alert(pickMsg("취소 승인"));
    var bad = sel.filter(function (r) { return [1, 2].indexOf(parseInt(r.site_id, 10)) < 0 || r.kind !== "취소"; });
    if (bad.length) return alert("취소 승인은 G마켓·옥션의 '취소' 줄만 됩니다. 다른 줄은 메인 PC 에서 해 주세요.");
    if (!confirm(sel.length + "건의 취소를 승인합니다(마켓에 보냅니다).")) return;
    runMany(null, sel.map(function (r) {
      return { path: "/api/v1/orders/" + enc(r.order_no) + "/cancel-approval", body: { acc: r.acc }, label: r.order_no };
    }), "취소 승인");
  }
  function one(what) {
    var sel = picked(), r = sel.length === 1 ? sel[0] : (sel.length === 0 ? current() : null);
    if (!r) alert(what + " 는 줄 하나를 골라 엽니다.");
    return r;
  }

  // ── 창(모달) ──────────────────────────────────────────────────
  function modal(title, body, buttons) {
    var box = $("modal-body"); clear(box);
    box.appendChild(el("h3", { text: title }));
    box.appendChild(body);
    var row = el("div", { cls: "row" });
    (buttons || []).forEach(function (b) { row.appendChild(b); });
    row.appendChild(el("button", { text: "닫기", onclick: closeModal }));
    box.appendChild(row);
    $("modal").classList.remove("hidden");
  }
  function closeModal() { $("modal").classList.add("hidden"); }

  function doCancel() {
    var r = one("주문취소"); if (!r) return;
    if (!r.cancel_ok) return alert("이 마켓은 판매자 취소를 지원하지 않습니다 — 마켓 판매자센터에서 취소해 주세요.");
    var sel = el("select"), det = el("input", { placeholder: "자세한 사유(기타를 골랐으면 꼭)" }), msg = el("p", { cls: "msg" });
    (S.meta.cancel_reasons || []).forEach(function (t) { sel.appendChild(el("option", { value: t, text: t })); });
    var body = el("div", {}, [el("p", { text: (r.site || "") + " · " + r.order_no + " · " + (r.goods || "") }),
      el("p", { cls: "tag-warn", text: "이 주문을 취소합니다. 되돌릴 수 없습니다." + (r.cancel_warn ? "\n" + r.cancel_warn : "") }),
      el("div", { cls: "form" }, [el("span", { text: "취소 사유" }), sel, el("span", { text: "자세히" }), det]), msg]);
    var go = el("button", { cls: "danger", text: "❌ 취소를 마켓에 보냅니다", onclick: function () {
      go.disabled = true; msg.textContent = "보내는 중…";
      cmd("POST", "/api/v1/orders/" + enc(r.order_no) + "/cancel", { idem: randHex(16),
          body: { memo_key: r.memo_key || r.order_no, reason: sel.value, detail: det.value.trim() } })
        .then(function (x) {
          go.disabled = false;
          if (!x.ok) { msg.textContent = "❌ " + x.message; return; }
          closeModal(); note("✅ " + (x.message || "취소했습니다.")); setTimeout(function () { load(true); }, 1200);
        });
    } });
    modal("주문취소 — 마켓에 보냅니다", body, [go]);
  }

  // 칸 이름은 PC 메모 창과 같은 뜻으로(링크 = 구매처 상품 링크 · 상태링크 = 주문·배송조회 링크).
  var MEMO_FIELDS = [["supplier", "구매처"], ["price", "구매가(발주금)"], ["link", "구매처 상품 링크"],
                     ["status_link", "주문·배송조회 링크"], ["product_name", "상품명(구매처)"], ["note", "비고"]];
  // 메모 창 — 맨 위 '🔗 링크 자동입력' 칸에 구매처 주문 링크를 붙여넣으면 **바로** 메인 PC 가 읽어
  // 아래 칸을 채운다(PC 메모 창의 '자동입력' 과 같은 규칙 — `common/memo_link`, 사용자 요청 2026-10-21).
  // ⚠ 채운 값은 저장하지 않는다 — 사람이 보고 [💾 메인 PC 에 저장] 을 눌러야 저장된다.
  // ⚠ 주문이 여러 건인 링크(주문 목록)는 목록을 보여 주고 고르게 한다(`pick_no`).
  function doMemo(row) {
    var r = row || one("메모"); if (!r) return;
    var memo = r.memo || {}, inputs = {}, form = el("div", { cls: "form" }), msg = el("p", { cls: "msg" });
    var pickBox = el("div", { cls: "pick" });
    var url = el("input", { placeholder: "구매처 주문 링크를 붙여넣으면 자동으로 채웁니다 (예: 네이버 주문 상세 주소)" });
    url.className = "memo-url";
    MEMO_FIELDS.forEach(function (f) {
      var inp = f[0] === "note" ? el("textarea") : el("input");
      inp.value = memo[f[0]] || ""; inputs[f[0]] = inp;
      form.appendChild(el("span", { text: f[1] })); form.appendChild(inp);
    });
    var key = r.memo_key || r.order_no, running = false, lastUrl = "", timer = null;
    function run(force, pickNo) {
      var u = url.value.trim();
      if (!/^https?:\/\//.test(u)) {
        if (force) msg.textContent = "위 '🔗 링크 자동입력' 칸에 구매처 주문 링크(https://…)를 붙여넣어 주세요.";
        return;
      }
      if (running || (!force && !pickNo && u === lastUrl)) return;
      running = true; lastUrl = u; again.disabled = true; clear(pickBox);
      msg.textContent = "메인 PC 가 링크를 읽는 중…(최대 1분)";
      var body = { url: u, order_no: r.order_no, goods: r.goods || "" };
      if (pickNo) body.pick_no = pickNo;
      cmd("POST", "/api/v1/memos/" + enc(key) + "/fill-from-link", { body: body }).then(function (x) {
        running = false; again.disabled = false;
        if (!x.ok || !x.data) { msg.textContent = "❌ " + x.message; return; }
        if (x.data.pick) {
          var items = Array.isArray(x.data.pick) ? x.data.pick : [];
          if (!items.length) { msg.textContent = "이 링크에서 주문을 고르지 못했습니다 — 그 주문의 상세 페이지 링크를 넣어 주세요."; return; }
          msg.textContent = "이 링크에는 주문이 여러 건입니다 — 이 주문(" + (r.goods || "") + ")에 맞는 것을 고르세요.";
          items.forEach(function (it) {
            pickBox.appendChild(el("button", { cls: "mini", text: [it.date, it.product, it.amount, it.status].filter(Boolean).join(" · "),
              title: "주문번호 " + (it.no || ""), onclick: function () { run(true, it.no); } }));
          });
          return;
        }
        Object.keys(x.data.fields || {}).forEach(function (k) { if (inputs[k]) inputs[k].value = x.data.fields[k] || ""; });
        msg.textContent = [x.message, x.data.warn].filter(Boolean).join(" ") + "\n확인한 뒤 [💾 메인 PC 에 저장] 을 누르세요.";
      });
    }
    // 붙여넣기·입력이 멈추면 바로 읽는다(같은 주소는 두 번 읽지 않는다 — 다시 읽으려면 [다시 읽기]).
    url.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { run(false); }, 600); });
    url.addEventListener("keydown", function (e) { if (e.key === "Enter") { clearTimeout(timer); run(true); } });
    var again = el("button", { text: "🔄 다시 읽기", title: "같은 링크를 메인 PC 가 다시 읽습니다", onclick: function () { run(true); } });
    var top = el("div", { cls: "memo-auto" }, [
      el("div", { cls: "small", text: "🔗 링크 자동입력 — 메인 PC 가 읽어 아래 칸을 채웁니다" }),
      el("div", { cls: "row" }, [url, again]), pickBox]);
    var save = el("button", { cls: "primary", text: "💾 메인 PC 에 저장", onclick: function () {
      var b = { order_no: r.order_no, goods: r.goods || "" };
      MEMO_FIELDS.forEach(function (f) { b[f[0]] = inputs[f[0]].value.trim(); });
      save.disabled = true; msg.textContent = "저장하는 중…";
      cmd("PUT", "/api/v1/memos/" + enc(key), { body: b, idem: randHex(16) }).then(function (x) {
        save.disabled = false;
        if (!x.ok) { msg.textContent = "❌ " + x.message; return; }
        closeModal(); note("✅ 메모를 메인 PC 에 저장했습니다(메인 화면에도 바로 반영)."); load(false);
      });
    } });
    modal("메모 — 메인 PC 에 저장(마켓에는 보내지 않습니다)", el("div", {}, [
      el("p", { text: (r.site || "") + " · " + r.order_no + " · " + (r.goods || "") }), top, form, msg]), [save]);
    setTimeout(function () { try { url.focus(); } catch (e) { /* 무시 */ } }, 50);
  }

  function doHistory(row) {
    var r = row || one("판매 내역"); if (!r) return;
    if (!r.goods_no) return alert("이 주문은 상품번호가 없어 지난 판매를 찾을 수 없습니다.");
    busy(true, "판매 내역을 받는 중…");
    cmd("GET", "/api/v1/orders/" + enc(r.order_no) + "/history", { query: { goods_no: r.goods_no, memo_key: r.memo_key } })
      .then(function (x) {
        busy(false);
        if (!x.ok || !x.data) return alert(x.message || "받지 못했습니다.");
        var d = x.data, past = d.past || {};
        var t = el("table"), th = el("tr");
        ["결제일", "마켓", "상태", "받는 분", "구매처·구매가", "비고", ""].forEach(function (h) { th.appendChild(el("th", { text: h })); });
        t.appendChild(th);
        (d.rows || []).forEach(function (o) {
          var p = past[o.order_no] || {}, tr = el("tr");
          [o.at, o.site, o.status, p.name, (o.supplier || "") + " " + (o.price || ""), o.note].forEach(function (v) {
            tr.appendChild(el("td", { text: v || "" })); });
          var td = el("td"); var u = safeUrl(o.link);
          // 구매처 링크 — 쿠팡이면 누를 때 파트너스로 바뀐다(openLink).
          if (u) td.appendChild(el("a", { href: "#", text: "구매처" + (isCoupang(u) ? "(파트너스)" : ""),
            onclick: function (e) { e.preventDefault(); openLink(u, isCoupang(u)); } }));
          tr.appendChild(td); t.appendChild(tr);
        });
        var lb = d.last_buy || {};
        modal("📜 같은 상품 판매 내역 — " + (d.goods || ""), el("div", {}, [
          el("p", { text: "판매 " + (d.sold || 0) + "건 · 취소 " + (d.cancelled || 0) + "건 · 수량 " + (d.qty || 0) +
                         " · 매출 " + won(d.sale) + "원" + (lb.supplier ? " · 최근 구매 " + lb.supplier + " " + (lb.price || "") : "") }),
          el("div", { cls: "table-wrap" }, [t])]), []);
      });
  }

  function doAnswer(r, ta) {
    var text = ta.value.trim();
    if (!text) return alert("답변을 적어 주세요.");
    if (!r.can_answer) return alert("이 문의는 문의번호가 없어 답할 수 없습니다.");
    if (!confirm("이 답변을 마켓에 보냅니다.")) return;
    busy(true, "답변을 보내는 중…");
    cmd("POST", "/api/v1/inquiries/" + enc(r.inquiry_id) + "/answer", { body: { text: text }, idem: randHex(16) })
      .then(function (x) {
        busy(false);
        if (!x.ok) { note("❌ " + x.message); return alert(x.message); }
        note("✅ " + (x.message || "답변을 보냈습니다.")); setTimeout(function () { load(true); }, 1200);
      });
  }

  // ── 주문통합검색 · 정산(권한) ──────────────────────────────────
  function ymd(d) { return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); }
  function dateIn(v) { return el("input", { type: "date", value: v }); }
  function drawSearchBar(tb) {
    var today = new Date(), wk = new Date(Date.now() - 7 * 864e5);
    var f = dateIn(ymd(wk)), t = dateIn(ymd(today)), q = el("input", { placeholder: "주문번호·상품명·받는 분·전화·관리코드" });
    q.style.minWidth = "260px";
    var go = el("button", { cls: "primary", text: "🔎 검색", onclick: function () {
      busy(true, "메인 PC 의 주문 DB 에서 찾는 중…");
      var g = S.gen;
      cmd("GET", "/api/v1/search", { query: { from: f.value, to: t.value, q: q.value.trim() } }).then(function (x) {
        if (stale(g)) return;
        busy(false);
        if (!x.ok || !x.data) { note("❌ " + x.message); return; }
        S.rows = x.data.rows || []; S.focus = -1; note((x.data.note || "") + " · " + S.rows.length + "건");
        drawGrid(); drawDetail();
      });
    } });
    q.addEventListener("keydown", function (e) { if (e.key === "Enter") go.click(); });
    [f, el("span", { text: "~" }), t, q, go].forEach(function (x) { tb.appendChild(x); });
  }
  function drawSettleBar(tb) {
    var today = new Date();
    var f = dateIn(ymd(new Date(today.getFullYear(), today.getMonth(), 1))), t = dateIn(ymd(today));
    function run() {
      busy(true, "정산을 계산하는 중…");
      var g = S.gen;
      cmd("GET", "/api/v1/settlement", { query: { from: f.value, to: t.value } }).then(function (x) {
        if (stale(g)) return;
        busy(false);
        if (!x.ok || !x.data) { note("❌ " + x.message); return; }
        S.rows = x.data.days || []; note(x.data.note || ""); drawGrid();
        var s = x.data.sum || {}, d = $("detail"); clear(d);
        d.appendChild(el("h3", { text: x.data.from + " ~ " + x.data.to }));
        var cards = el("div", { cls: "cards" });
        [["주문", (s.count || 0) + "건"], ["매출", won(s.sale) + "원"], ["받을 돈", won(s.settle) + "원"],
         ["물건 값", won(s.order_amount) + "원"], ["광고비", won(s.ad) + "원"], ["내가 번 돈", won(s.profit) + "원"]]
          .forEach(function (c) { cards.appendChild(el("div", { cls: "card" }, [el("span", { cls: "muted", text: c[0] }), el("b", { text: c[1] })])); });
        d.appendChild(cards);
      });
    }
    function quick(label, a, b) { tb.appendChild(el("button", { text: label, onclick: function () { f.value = ymd(a); t.value = ymd(b); run(); } })); }
    var y = new Date(Date.now() - 864e5);
    quick("오늘", today, today); quick("어제", y, y);
    quick("이번 달", new Date(today.getFullYear(), today.getMonth(), 1), today);
    quick("지난달", new Date(today.getFullYear(), today.getMonth() - 1, 1), new Date(today.getFullYear(), today.getMonth(), 0));
    [f, el("span", { text: "~" }), t, el("button", { cls: "primary", text: "계산", onclick: run })].forEach(function (x) { tb.appendChild(x); });
  }

  // ── 상태 확인 · 알림 ───────────────────────────────────────────
  // 메인이 알린 바로 그 사건(`alert_log` — 휴대폰과 같은 기록)마다 종류별로 울린다(사용자 요청
  // 2026-10-21): 신규주문 · 취소/반품/교환 · 긴급/문의. 종류마다 **다른 소리 + 음성 안내**,
  // 배너에 종류별 문구, 그 탭과 타이틀바가 **눌러 볼 때까지** 깜빡인다.
  // ⚠ 소리는 이 화면을 한 번 누른 뒤에야 난다(브라우저 규칙) — 로그인 버튼을 누르면 풀린다.
  // ⚠ 처음 연결했을 때 이미 있던 알림은 울리지 않는다(번호만 기억 — `S.alertSeq`).
  var watchTimer = null, blinkTimer = null, audio = null;
  var KIND_TAB = { "new": "new", cancel: "claim", "return": "claim", exchange: "claim", qna: "qna" };
  var KIND_LABEL = { "new": "신규주문", cancel: "주문취소", "return": "반품", exchange: "교환", qna: "긴급 문의" };
  // [주파수, 시작(초), 길이(초)] — 신규=밝게 올라가는 세 음 · 클레임=내려가는 두 음 · 문의=급한 짧은 세 번
  var TONES = {
    "new": [[784, 0, 0.16], [988, 0.18, 0.16], [1175, 0.36, 0.3]],
    claim: [[660, 0, 0.3], [440, 0.34, 0.45]],
    qna: [[1320, 0, 0.1], [1320, 0.16, 0.1], [1320, 0.32, 0.1], [990, 0.5, 0.25]]
  };
  S.alertTabs = {};
  S.soundOn = (function () { try { return localStorage.getItem("aflow_subpc_sound") !== "0"; } catch (e) { return true; } })();
  function unlockSound() {
    try { if (!audio) audio = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { audio = null; }
    try { if (audio && audio.state === "suspended") audio.resume(); } catch (e) { /* 무시 */ }
  }
  function tones(list, delay) {
    if (!audio || !S.soundOn) return;
    try {
      if (audio.state === "suspended") audio.resume();
      var t0 = audio.currentTime + (delay || 0);
      list.forEach(function (x) {
        var o = audio.createOscillator(), g = audio.createGain();
        o.type = "triangle"; o.frequency.value = x[0]; o.connect(g); g.connect(audio.destination);
        g.gain.setValueAtTime(0.0001, t0 + x[1]);
        g.gain.exponentialRampToValueAtTime(0.3, t0 + x[1] + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + x[1] + x[2]);
        o.start(t0 + x[1]); o.stop(t0 + x[1] + x[2] + 0.02);
      });
    } catch (e) { /* 소리가 막힌 브라우저 */ }
  }
  function speak(text) {
    if (!S.soundOn || !window.speechSynthesis || !text) return;
    try {
      var u = new SpeechSynthesisUtterance(text);
      u.lang = "ko-KR"; u.rate = 1.05;
      window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
    } catch (e) { /* 음성이 없는 PC */ }
  }
  function beep() { tones(TONES["new"]); }
  function setState(t) { $("hd-state").textContent = t; }
  function startWatch() { stopWatch(); watch(); watchTimer = setInterval(watch, 20000); }
  function stopWatch() { if (watchTimer) clearInterval(watchTimer); watchTimer = null; }
  function watch() {
    cmd("GET", "/api/v1/status").then(function (x) {
      if (!x.ok || !x.data) return;
      setState("🟢 메인 PC 에 연결됨" + (S.latency != null ? " · " + S.latency + "ms" : "") +
               (x.data.readonly ? " · ⚠ 메인이 '조회 전용' 입니다(마켓에 보내는 동작은 막힘)" : ""));
      if (x.data.counts) { S.counts = x.data.counts; drawTabs(); }
      var seq = x.data.alert_seq;
      if (S.alertSeq != null && seq != null && seq > S.alertSeq) {
        var last = S.alertSeq;
        alarm((x.data.alert_log || []).filter(function (e) { return e.seq > last; }));
      }
      if (seq != null) S.alertSeq = seq;
    });
  }
  function alarm(events) {
    // 종류별로 합친다(20초 사이 두 번 들어왔으면 한 번만 울린다).
    var notes = [], kinds = {};
    (events || []).forEach(function (e) {
      (e.notes || []).forEach(function (n) {
        if (!KIND_LABEL[n.kind]) return;
        notes.push(n); kinds[n.kind] = (kinds[n.kind] || 0) + (n.n || 1);
      });
    });
    var got = ["qna", "cancel", "return", "exchange", "new"].filter(function (k) { return kinds[k]; });  // 급한 것부터
    // 소리 — 종류마다 다른 음을 차례로, 그다음 음성 "긴급 문의 1건, 신규주문 2건 들어왔습니다"
    var delay = 0, played = {};
    got.forEach(function (k) {
      var g = k === "new" ? "new" : k === "qna" ? "qna" : "claim";
      if (played[g]) return;
      played[g] = true; tones(TONES[g], delay); delay += 0.9;
    });
    if (!got.length) { beep(); delay = 0.9; }
    var say = got.map(function (k) { return KIND_LABEL[k] + " " + kinds[k] + "건"; }).join(", ");
    S.lastSpeech = say ? say + " 들어왔습니다" : "새 알림이 있습니다";
    setTimeout(function () { speak(S.lastSpeech); }, delay * 1000 + 100);
    // 배너 — 종류별 한 줄씩(메인이 만든 문구 그대로)
    var b = $("banner"); clear(b);
    if (notes.length) {
      notes.slice(0, 6).forEach(function (n) {
        b.appendChild(el("div", { cls: "al al-" + (KIND_TAB[n.kind] || "new"),
          text: "🔔 " + String(n.title || "").replace(/^A-Flow — /, "") + (n.body ? " — " + n.body : "") }));
      });
    } else {
      b.appendChild(el("div", { text: "🔔 메인 PC 에 새 알림(새 주문·취소·문의)이 있습니다" }));
    }
    b.appendChild(el("div", { cls: "small", text: "눌러서 닫기" }));
    b.classList.remove("hidden");
    // 탭 — 그 탭을 열 때까지 깜빡인다
    got.forEach(function (k) { S.alertTabs[KIND_TAB[k]] = true; });
    if (!got.length) S.alertTabs["new"] = true;
    if (!document.hidden) delete S.alertTabs[S.tab];         // 보고 있는 탭은 아래에서 새로 읽는다
    drawTabs();
    if (["new", "ship", "claim", "qna"].indexOf(S.tab) >= 0) load(false);
    // 타이틀바 — 이 화면을 누르거나 키를 누를 때까지 깜빡인다(작업표시줄에서도 보인다)
    var head = got.length ? got.map(function (k) { return KIND_LABEL[k] + " " + kinds[k]; }).join(" · ") : "새 알림";
    startBlink("🔔 " + head + " — A-FLOW");
  }
  function startBlink(text) {
    stopBlink();
    var on = true;
    document.body.classList.add("alerting");
    document.title = text;
    blinkTimer = setInterval(function () { on = !on; document.title = on ? text : "A-FLOW 서브PC"; }, 800);
  }
  function stopBlink() {
    if (blinkTimer) clearInterval(blinkTimer);
    blinkTimer = null; document.title = "A-FLOW 서브PC";
    document.body.classList.remove("alerting");
  }
  // 사람이 화면을 만지면(누르기·키) 타이틀바 깜빡임은 멈춘다. 탭 깜빡임은 그 탭을 열어야 멈춘다.
  ["mousedown", "keydown"].forEach(function (ev) {
    document.addEventListener(ev, function () { if (blinkTimer && !document.hidden) stopBlink(); }, true);
  });
  function drawSoundBtn() {
    var x = $("hd-sound");
    if (!x) return;
    x.textContent = S.soundOn ? "🔔 소리 켬" : "🔕 소리 끔";
    x.title = S.soundOn ? "새 주문·취소·문의가 오면 소리와 음성으로 알립니다 — 누르면 끕니다" : "누르면 알림 소리를 켭니다";
  }

  // ── 연결 ──────────────────────────────────────────────────────
  $("lg-go").addEventListener("click", doLogin);
  ["lg-id", "lg-pw", "lg-dev"].forEach(function (id) {
    $(id).addEventListener("keydown", function (e) { if (e.key === "Enter") doLogin(); });
  });
  $("hd-logout").addEventListener("click", function () {
    if (!confirm("로그아웃할까요?")) return;
    api("POST", "/api/v1/auth/logout", { body: {} }).then(function () { loggedOut("로그아웃했습니다."); });
  });
  $("banner").addEventListener("click", function () { $("banner").classList.add("hidden"); stopBlink(); });
  $("hd-sound").addEventListener("click", function () {
    S.soundOn = !S.soundOn;
    try { localStorage.setItem("aflow_subpc_sound", S.soundOn ? "1" : "0"); } catch (e) { /* 무시 */ }
    drawSoundBtn(); unlockSound();
    if (S.soundOn) tones(TONES["new"]);                 // 켜면 한 번 들려준다(소리 확인)
  });
  drawSoundBtn();
  $("modal").addEventListener("click", function (e) { if (e.target === $("modal")) closeModal(); });
  document.addEventListener("click", unlockSound);

  // ── 오른쪽 상세 칸 폭 — 가운데 막대를 끌어 조절하고 이 브라우저에 기억한다 ──
  (function splitter() {
    var bar = $("split"), pane = $("detail");
    if (!bar || !pane) return;
    var saved = parseInt(lget("aflow_subpc_detail_w"), 10);
    if (saved >= 240) pane.style.width = saved + "px";
    var drag = null;
    bar.addEventListener("mousedown", function (e) {
      drag = { x: e.clientX, w: pane.getBoundingClientRect().width }; e.preventDefault();
      document.body.classList.add("dragging");
    });
    document.addEventListener("mousemove", function (e) {
      if (!drag) return;
      var w = Math.max(240, Math.min(window.innerWidth - 360, drag.w + (drag.x - e.clientX)));
      pane.style.width = w + "px";
    });
    document.addEventListener("mouseup", function () {
      if (!drag) return;
      drag = null; document.body.classList.remove("dragging");
      lset("aflow_subpc_detail_w", String(Math.round(pane.getBoundingClientRect().width)));
    });
    bar.addEventListener("dblclick", function () {      // 두 번 누르면 처음 폭으로
      pane.style.width = ""; lset("aflow_subpc_detail_w", "");
    });
  })();

  if (S.token) start(); else showLogin("");
})();
